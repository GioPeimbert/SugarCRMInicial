<?php
// created: 2021-12-29 16:40:20
$dictionary["E1_candidates"]["fields"]["e1_candidates_tasks"] = array (
  'name' => 'e1_candidates_tasks',
  'type' => 'link',
  'relationship' => 'e1_candidates_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_E1_CANDIDATES_TASKS_FROM_E1_CANDIDATES_TITLE',
  'id_name' => 'e1_candidates_taskse1_candidates_ida',
  'link-type' => 'many',
  'side' => 'left',
);
