<?php
 // created: 2021-12-29 16:40:20
$layout_defs["E1_candidates"]["subpanel_setup"]['e1_candidates_documents'] = array (
  'order' => 100,
  'module' => 'Documents',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_E1_CANDIDATES_DOCUMENTS_FROM_DOCUMENTS_TITLE',
  'get_subpanel_data' => 'e1_candidates_documents',
);
