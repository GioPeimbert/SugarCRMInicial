<?php
 // created: 2021-12-29 16:27:11
$layout_defs["E1_candidates"]["subpanel_setup"]['e1_candidates_tasks'] = array (
  'order' => 100,
  'module' => 'Tasks',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_E1_CANDIDATES_TASKS_FROM_TASKS_TITLE',
  'get_subpanel_data' => 'e1_candidates_tasks',
);
