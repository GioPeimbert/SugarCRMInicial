<?php
// created: 2021-12-29 16:27:10
$dictionary["E1_candidates"]["fields"]["e1_candidates_documents"] = array (
  'name' => 'e1_candidates_documents',
  'type' => 'link',
  'relationship' => 'e1_candidates_documents',
  'source' => 'non-db',
  'module' => 'Documents',
  'bean_name' => 'Document',
  'vname' => 'LBL_E1_CANDIDATES_DOCUMENTS_FROM_E1_CANDIDATES_TITLE',
  'id_name' => 'e1_candidates_documentse1_candidates_ida',
  'link-type' => 'many',
  'side' => 'left',
);
