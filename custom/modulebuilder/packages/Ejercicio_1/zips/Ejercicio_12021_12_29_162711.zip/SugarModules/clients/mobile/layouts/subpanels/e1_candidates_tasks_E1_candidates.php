<?php
// created: 2021-12-29 16:27:11
$viewdefs['E1_candidates']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_E1_CANDIDATES_TASKS_FROM_TASKS_TITLE',
  'context' => 
  array (
    'link' => 'e1_candidates_tasks',
  ),
);