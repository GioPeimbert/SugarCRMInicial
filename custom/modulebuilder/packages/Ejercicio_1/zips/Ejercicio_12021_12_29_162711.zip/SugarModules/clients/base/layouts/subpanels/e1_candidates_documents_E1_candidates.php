<?php
// created: 2021-12-29 16:27:10
$viewdefs['E1_candidates']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_E1_CANDIDATES_DOCUMENTS_FROM_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'e1_candidates_documents',
  ),
);