<?php
// created: 2022-01-25 14:29:14
$dictionary["E2_properties"]["fields"]["mi_images_e2_properties"] = array (
  'name' => 'mi_images_e2_properties',
  'type' => 'link',
  'relationship' => 'mi_images_e2_properties',
  'source' => 'non-db',
  'module' => 'MI_images',
  'bean_name' => false,
  'vname' => 'LBL_MI_IMAGES_E2_PROPERTIES_FROM_E2_PROPERTIES_TITLE',
  'id_name' => 'mi_images_e2_propertiese2_properties_ida',
  'link-type' => 'many',
  'side' => 'left',
);
