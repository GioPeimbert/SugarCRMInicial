<?php
// created: 2022-01-25 14:29:14
$viewdefs['E2_properties']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MI_IMAGES_E2_PROPERTIES_FROM_MI_IMAGES_TITLE',
  'context' => 
  array (
    'link' => 'mi_images_e2_properties',
  ),
);

$viewdefs['E2_properties']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MI_IMAGES_E2_PROPERTIES_FROM_MI_IMAGES_TITLE',
  'context' => 
  array (
    'link' => 'mi_images_e2_properties',
  ),
);