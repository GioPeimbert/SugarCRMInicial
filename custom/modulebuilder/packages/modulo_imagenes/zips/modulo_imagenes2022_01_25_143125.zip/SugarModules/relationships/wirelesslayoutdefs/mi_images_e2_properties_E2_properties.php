<?php
 // created: 2022-01-25 14:31:25
$layout_defs["E2_properties"]["subpanel_setup"]['mi_images_e2_properties'] = array (
  'order' => 100,
  'module' => 'MI_images',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_MI_IMAGES_E2_PROPERTIES_FROM_MI_IMAGES_TITLE',
  'get_subpanel_data' => 'mi_images_e2_properties',
);
