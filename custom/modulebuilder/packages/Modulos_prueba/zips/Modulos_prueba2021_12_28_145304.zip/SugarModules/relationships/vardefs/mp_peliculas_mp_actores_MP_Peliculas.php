<?php
// created: 2021-12-28 14:53:04
$dictionary["MP_Peliculas"]["fields"]["mp_peliculas_mp_actores"] = array (
  'name' => 'mp_peliculas_mp_actores',
  'type' => 'link',
  'relationship' => 'mp_peliculas_mp_actores',
  'source' => 'non-db',
  'module' => 'MP_Actores',
  'bean_name' => false,
  'vname' => 'LBL_MP_PELICULAS_MP_ACTORES_FROM_MP_ACTORES_TITLE',
  'id_name' => 'mp_peliculas_mp_actoresmp_actores_idb',
);
