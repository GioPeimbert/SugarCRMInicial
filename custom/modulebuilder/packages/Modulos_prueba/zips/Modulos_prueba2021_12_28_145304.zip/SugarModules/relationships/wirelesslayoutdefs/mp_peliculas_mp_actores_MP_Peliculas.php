<?php
 // created: 2021-12-28 14:53:04
$layout_defs["MP_Peliculas"]["subpanel_setup"]['mp_peliculas_mp_actores'] = array (
  'order' => 100,
  'module' => 'MP_Actores',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_MP_PELICULAS_MP_ACTORES_FROM_MP_ACTORES_TITLE',
  'get_subpanel_data' => 'mp_peliculas_mp_actores',
);
