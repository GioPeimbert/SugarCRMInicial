<?php
// created: 2021-12-28 14:53:04
$dictionary["MP_Peliculas"]["fields"]["mp_peliculas_mp_actores_1"] = array (
  'name' => 'mp_peliculas_mp_actores_1',
  'type' => 'link',
  'relationship' => 'mp_peliculas_mp_actores_1',
  'source' => 'non-db',
  'module' => 'MP_Actores',
  'bean_name' => false,
  'vname' => 'LBL_MP_PELICULAS_MP_ACTORES_1_FROM_MP_ACTORES_TITLE',
  'id_name' => 'mp_peliculas_mp_actores_1mp_actores_idb',
);
