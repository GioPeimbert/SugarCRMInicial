<?php
// created: 2021-12-29 11:39:12
$dictionary["MP_directores"]["fields"]["mp_directores_mp_peliculas"] = array (
  'name' => 'mp_directores_mp_peliculas',
  'type' => 'link',
  'relationship' => 'mp_directores_mp_peliculas',
  'source' => 'non-db',
  'module' => 'MP_peliculas',
  'bean_name' => 'MP_peliculas',
  'vname' => 'LBL_MP_DIRECTORES_MP_PELICULAS_FROM_MP_DIRECTORES_TITLE',
  'id_name' => 'mp_directores_mp_peliculasmp_directores_ida',
  'link-type' => 'many',
  'side' => 'left',
);
