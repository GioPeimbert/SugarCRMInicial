<?php
// created: 2021-12-29 11:39:12
$dictionary["MP_actores"]["fields"]["mp_peliculas_mp_actores"] = array (
  'name' => 'mp_peliculas_mp_actores',
  'type' => 'link',
  'relationship' => 'mp_peliculas_mp_actores',
  'source' => 'non-db',
  'module' => 'MP_peliculas',
  'bean_name' => 'MP_peliculas',
  'vname' => 'LBL_MP_PELICULAS_MP_ACTORES_FROM_MP_PELICULAS_TITLE',
  'id_name' => 'mp_peliculas_mp_actoresmp_peliculas_ida',
);
