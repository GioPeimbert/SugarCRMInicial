<?php
 // created: 2021-12-28 17:54:34
$layout_defs["MP_actores"]["subpanel_setup"]['mp_peliculas_mp_actores'] = array (
  'order' => 100,
  'module' => 'MP_peliculas',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_MP_PELICULAS_MP_ACTORES_FROM_MP_PELICULAS_TITLE',
  'get_subpanel_data' => 'mp_peliculas_mp_actores',
);
