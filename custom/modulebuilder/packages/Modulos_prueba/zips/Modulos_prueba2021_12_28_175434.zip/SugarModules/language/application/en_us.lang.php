<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['calificacion_list'][1] = '1';
$app_list_strings['calificacion_list'][2] = '2';
$app_list_strings['calificacion_list'][3] = '3';
$app_list_strings['calificacion_list'][4] = '4';
$app_list_strings['calificacion_list'][5] = '5';
$app_list_strings['moduleList']['MP_actores'] = 'Actores';
$app_list_strings['moduleList']['MP_peliculas'] = 'Películas';
$app_list_strings['moduleList']['MP_directores'] = 'Directores';
$app_list_strings['moduleListSingular']['MP_actores'] = 'Actor';
$app_list_strings['moduleListSingular']['MP_peliculas'] = 'Pelicula';
$app_list_strings['moduleListSingular']['MP_directores'] = 'Director';
