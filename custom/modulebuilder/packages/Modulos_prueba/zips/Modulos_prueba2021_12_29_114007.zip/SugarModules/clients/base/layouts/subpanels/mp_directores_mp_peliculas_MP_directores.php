<?php
// created: 2021-12-28 17:54:32
$viewdefs['MP_directores']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MP_DIRECTORES_MP_PELICULAS_FROM_MP_PELICULAS_TITLE',
  'context' => 
  array (
    'link' => 'mp_directores_mp_peliculas',
  ),
);

$viewdefs['MP_directores']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MP_DIRECTORES_MP_PELICULAS_FROM_MP_PELICULAS_TITLE',
  'context' => 
  array (
    'link' => 'mp_directores_mp_peliculas',
  ),
);

$viewdefs['MP_directores']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MP_DIRECTORES_MP_PELICULAS_FROM_MP_PELICULAS_TITLE',
  'context' => 
  array (
    'link' => 'mp_directores_mp_peliculas',
  ),
);