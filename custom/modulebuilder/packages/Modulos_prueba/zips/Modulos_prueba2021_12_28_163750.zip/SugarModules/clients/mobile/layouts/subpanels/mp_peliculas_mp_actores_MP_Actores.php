<?php
// created: 2021-12-28 14:53:04
$viewdefs['MP_Actores']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MP_PELICULAS_MP_ACTORES_FROM_MP_PELICULAS_TITLE',
  'context' => 
  array (
    'link' => 'mp_peliculas_mp_actores',
  ),
);

$viewdefs['MP_Actores']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MP_PELICULAS_MP_ACTORES_FROM_MP_PELICULAS_TITLE',
  'context' => 
  array (
    'link' => 'mp_peliculas_mp_actores',
  ),
);