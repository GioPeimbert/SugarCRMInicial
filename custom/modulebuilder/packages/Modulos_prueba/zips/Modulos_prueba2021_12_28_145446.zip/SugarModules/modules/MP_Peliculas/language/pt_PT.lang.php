<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equipas',
  'LBL_TEAMS' => 'Equipas',
  'LBL_TEAM_ID' => 'Id Equipa',
  'LBL_ASSIGNED_TO_ID' => 'ID de Utilizador Atribuído',
  'LBL_ASSIGNED_TO_NAME' => 'Atribuído a',
  'LBL_TAGS_LINK' => 'Etiquetas',
  'LBL_TAGS' => 'Etiquetas',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data da Criação',
  'LBL_DATE_MODIFIED' => 'Data da Modificação',
  'LBL_MODIFIED' => 'Modificado Por',
  'LBL_MODIFIED_ID' => 'Modificado Por Id',
  'LBL_MODIFIED_NAME' => 'Modificado Por Nome',
  'LBL_CREATED' => 'Criado Por',
  'LBL_CREATED_ID' => 'ID do Utilizador que Criou',
  'LBL_DOC_OWNER' => 'Proprietário do Documento',
  'LBL_USER_FAVORITES' => 'Utilizadores que adicionaram aos Favoritos',
  'LBL_DESCRIPTION' => 'Descrição',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Nome',
  'LBL_CREATED_USER' => 'Criado por Utilizador',
  'LBL_MODIFIED_USER' => 'Modificado por Utilizador',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Remover',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificado Por Nome',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Criado por Nome',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Películas Lista',
  'LBL_MODULE_NAME' => 'Películas',
  'LBL_MODULE_TITLE' => 'Películas',
  'LBL_MODULE_NAME_SINGULAR' => 'Pelicula',
  'LBL_HOMEPAGE_TITLE' => 'Minha Películas',
  'LNK_NEW_RECORD' => 'Criar Pelicula',
  'LNK_LIST' => 'Vista Películas',
  'LNK_IMPORT_MP_PELICULAS' => 'Importar Películas',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Pelicula',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Histórico',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Fluxo de Atividades',
  'LBL_MP_PELICULAS_SUBPANEL_TITLE' => 'Películas',
  'LBL_NEW_FORM_TITLE' => 'Novo Pelicula',
  'LNK_IMPORT_VCARD' => 'Importar Pelicula vCard',
  'LBL_IMPORT' => 'Importar Películas',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Pelicula record by importing a vCard from your file system.',
  'LBL_MP_PELICULAS_FOCUS_DRAWER_DASHBOARD' => 'Películas Panel de Enfoque',
  'LBL_MP_PELICULAS_RECORD_DASHBOARD' => 'Películas Tablero de Registro',
  'LBL_CALIFICACION' => 'Calificación',
);