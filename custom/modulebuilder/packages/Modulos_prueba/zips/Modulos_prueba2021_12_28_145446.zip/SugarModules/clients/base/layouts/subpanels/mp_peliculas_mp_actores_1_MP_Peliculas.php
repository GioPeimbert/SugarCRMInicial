<?php
// created: 2021-12-28 14:53:04
$viewdefs['MP_Peliculas']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MP_PELICULAS_MP_ACTORES_1_FROM_MP_ACTORES_TITLE',
  'context' => 
  array (
    'link' => 'mp_peliculas_mp_actores_1',
  ),
);

$viewdefs['MP_Peliculas']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MP_PELICULAS_MP_ACTORES_1_FROM_MP_ACTORES_TITLE',
  'context' => 
  array (
    'link' => 'mp_peliculas_mp_actores_1',
  ),
);