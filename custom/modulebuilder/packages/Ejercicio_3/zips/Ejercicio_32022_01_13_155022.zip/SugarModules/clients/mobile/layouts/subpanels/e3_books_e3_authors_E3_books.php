<?php
// created: 2022-01-13 15:42:33
$viewdefs['E3_books']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_E3_BOOKS_E3_AUTHORS_FROM_E3_AUTHORS_TITLE',
  'context' => 
  array (
    'link' => 'e3_books_e3_authors',
  ),
);

$viewdefs['E3_books']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_E3_BOOKS_E3_AUTHORS_FROM_E3_AUTHORS_TITLE',
  'context' => 
  array (
    'link' => 'e3_books_e3_authors',
  ),
);