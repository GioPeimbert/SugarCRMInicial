<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Екип',
  'LBL_TEAMS' => 'Екип',
  'LBL_TEAM_ID' => 'Екип',
  'LBL_ASSIGNED_TO_ID' => 'Отговорник',
  'LBL_ASSIGNED_TO_NAME' => 'Потребител',
  'LBL_TAGS_LINK' => 'Етикети',
  'LBL_TAGS' => 'Етикети',
  'LBL_ID' => 'Идентификатор',
  'LBL_DATE_ENTERED' => 'Създадено на',
  'LBL_DATE_MODIFIED' => 'Модифицирано на',
  'LBL_MODIFIED' => 'Модифицирано от',
  'LBL_MODIFIED_ID' => 'Модифицирано от',
  'LBL_MODIFIED_NAME' => 'Модифицирано от',
  'LBL_CREATED' => 'Създадено от',
  'LBL_CREATED_ID' => 'Създадено от',
  'LBL_DOC_OWNER' => 'Собственик на документа',
  'LBL_USER_FAVORITES' => 'Потребители които харесват',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_DELETED' => 'Изтрити',
  'LBL_NAME' => 'Име',
  'LBL_CREATED_USER' => 'Създадено от',
  'LBL_MODIFIED_USER' => 'Модифицирано от',
  'LBL_LIST_NAME' => 'Име',
  'LBL_EDIT_BUTTON' => 'Редактирай',
  'LBL_REMOVE' => 'Премахни',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Модифицирано от',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Създадено от Име',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Autores Списък',
  'LBL_MODULE_NAME' => 'Autores',
  'LBL_MODULE_TITLE' => 'Autores',
  'LBL_MODULE_NAME_SINGULAR' => 'Autor',
  'LBL_HOMEPAGE_TITLE' => 'Мои Autores',
  'LNK_NEW_RECORD' => 'Създай Autor',
  'LNK_LIST' => 'Изглед Autores',
  'LNK_IMPORT_E3_AUTHORS' => 'Importar Autores',
  'LBL_SEARCH_FORM_TITLE' => 'Търси Autor',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'История',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Дейности',
  'LBL_E3_AUTHORS_SUBPANEL_TITLE' => 'Autores',
  'LBL_NEW_FORM_TITLE' => 'Нов Autor',
  'LNK_IMPORT_VCARD' => 'Importar Autor vCard',
  'LBL_IMPORT' => 'Importar Autores',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Autor record by importing a vCard from your file system.',
  'LBL_E3_AUTHORS_FOCUS_DRAWER_DASHBOARD' => 'Autores Panel de Enfoque',
  'LBL_E3_AUTHORS_RECORD_DASHBOARD' => 'Autores Tablero de Registro',
  'LBL_TCT_ID_AUTOR_TXF' => 'ID Autor',
  'LBL_TCT_ID_LIBRO_TXF' => 'ID Libro',
  'LBL_TCT_NOMBRE_TXF' => 'Primer Nombre',
  'LBL_TCT_APELLIDO_TXF' => 'Apellido Paterno',
);