<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Team',
  'LBL_TEAMS' => 'Team',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Tildelt bruker Id',
  'LBL_ASSIGNED_TO_NAME' => 'Tildelt til',
  'LBL_TAGS_LINK' => 'Etiketter',
  'LBL_TAGS' => 'Etiketter',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Opprettet dato',
  'LBL_DATE_MODIFIED' => 'Endret Dato',
  'LBL_MODIFIED' => 'Endret av',
  'LBL_MODIFIED_ID' => 'Endret av Id',
  'LBL_MODIFIED_NAME' => 'Endret av Navn',
  'LBL_CREATED' => 'Opprettet av',
  'LBL_CREATED_ID' => 'Opprettet av Id',
  'LBL_DOC_OWNER' => 'Dokumenteier',
  'LBL_USER_FAVORITES' => 'Brukere som favoriserer',
  'LBL_DESCRIPTION' => 'Beskrivelse',
  'LBL_DELETED' => 'Slettet',
  'LBL_NAME' => 'Navn',
  'LBL_CREATED_USER' => 'Opprettet av bruker',
  'LBL_MODIFIED_USER' => 'Endret av bruker',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_EDIT_BUTTON' => 'Rediger',
  'LBL_REMOVE' => 'Fjern',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Endret av Navn',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Opprett av navn',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Autores Liste',
  'LBL_MODULE_NAME' => 'Autores',
  'LBL_MODULE_TITLE' => 'Autores',
  'LBL_MODULE_NAME_SINGULAR' => 'Autor',
  'LBL_HOMEPAGE_TITLE' => 'Min Autores',
  'LNK_NEW_RECORD' => 'Opprett Autor',
  'LNK_LIST' => 'Vis Autores',
  'LNK_IMPORT_E3_AUTHORS' => 'Importar Autores',
  'LBL_SEARCH_FORM_TITLE' => 'Søk Autor',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historie',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktivitetstrøm',
  'LBL_E3_AUTHORS_SUBPANEL_TITLE' => 'Autores',
  'LBL_NEW_FORM_TITLE' => 'Ny Autor',
  'LNK_IMPORT_VCARD' => 'Importar Autor vCard',
  'LBL_IMPORT' => 'Importar Autores',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Autor record by importing a vCard from your file system.',
  'LBL_E3_AUTHORS_FOCUS_DRAWER_DASHBOARD' => 'Autores Panel de Enfoque',
  'LBL_E3_AUTHORS_RECORD_DASHBOARD' => 'Autores Tablero de Registro',
  'LBL_TCT_ID_AUTOR_TXF' => 'ID Autor',
  'LBL_TCT_ID_LIBRO_TXF' => 'ID Libro',
  'LBL_TCT_NOMBRE_TXF' => 'Primer Nombre',
  'LBL_TCT_APELLIDO_TXF' => 'Apellido Paterno',
);