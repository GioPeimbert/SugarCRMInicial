<?php
 // created: 2022-01-13 15:42:33
$layout_defs["E3_books"]["subpanel_setup"]['e3_books_e3_authors'] = array (
  'order' => 100,
  'module' => 'E3_authors',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_E3_BOOKS_E3_AUTHORS_FROM_E3_AUTHORS_TITLE',
  'get_subpanel_data' => 'e3_books_e3_authors',
);
