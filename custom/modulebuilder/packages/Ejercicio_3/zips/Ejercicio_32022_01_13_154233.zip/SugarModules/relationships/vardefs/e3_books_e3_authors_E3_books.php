<?php
// created: 2022-01-13 15:42:33
$dictionary["E3_books"]["fields"]["e3_books_e3_authors"] = array (
  'name' => 'e3_books_e3_authors',
  'type' => 'link',
  'relationship' => 'e3_books_e3_authors',
  'source' => 'non-db',
  'module' => 'E3_authors',
  'bean_name' => false,
  'vname' => 'LBL_E3_BOOKS_E3_AUTHORS_FROM_E3_BOOKS_TITLE',
  'id_name' => 'e3_books_e3_authorse3_books_ida',
  'link-type' => 'many',
  'side' => 'left',
);
