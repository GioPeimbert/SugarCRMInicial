<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Grupet',
  'LBL_TEAMS' => 'Grupet',
  'LBL_TEAM_ID' => 'Id e grupit',
  'LBL_ASSIGNED_TO_ID' => 'Id e përdoruesit të caktuar',
  'LBL_ASSIGNED_TO_NAME' => 'Përdorues',
  'LBL_TAGS_LINK' => 'Etiketat',
  'LBL_TAGS' => 'Etiketat',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Të dhënat e krijuara',
  'LBL_DATE_MODIFIED' => 'Të dhënat e modifikuara',
  'LBL_MODIFIED' => 'Modifikuar nga',
  'LBL_MODIFIED_ID' => 'Modifikuar nga Id',
  'LBL_MODIFIED_NAME' => 'Modifikuar nga emri',
  'LBL_CREATED' => 'Krijuar nga',
  'LBL_CREATED_ID' => 'Krijuar nga Id',
  'LBL_DOC_OWNER' => 'Zotëruesi i dokumentit',
  'LBL_USER_FAVORITES' => 'Përdoruesit të cilët preferojnë',
  'LBL_DESCRIPTION' => 'Përshkrim',
  'LBL_DELETED' => 'E fshirë',
  'LBL_NAME' => 'Emri',
  'LBL_CREATED_USER' => 'Krijuar nga përdoruesi',
  'LBL_MODIFIED_USER' => 'Modifikuar nga përdoruesi',
  'LBL_LIST_NAME' => 'Emri',
  'LBL_EDIT_BUTTON' => 'Ndrysho',
  'LBL_REMOVE' => 'Hiqe',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modifikuar nga emri',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Krijuar sipas emrit',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Libros lista',
  'LBL_MODULE_NAME' => 'Libros',
  'LBL_MODULE_TITLE' => 'Libros',
  'LBL_MODULE_NAME_SINGULAR' => 'Libro',
  'LBL_HOMEPAGE_TITLE' => 'Mia Libros',
  'LNK_NEW_RECORD' => 'Krijo Libro',
  'LNK_LIST' => 'Pamje Libros',
  'LNK_IMPORT_E3_BOOKS' => 'Importar Libros',
  'LBL_SEARCH_FORM_TITLE' => 'Kërkim Libro',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'shiko historinë',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktivitetet',
  'LBL_E3_BOOKS_SUBPANEL_TITLE' => 'Libros',
  'LBL_NEW_FORM_TITLE' => 'E re Libro',
  'LNK_IMPORT_VCARD' => 'Importar Libro vCard',
  'LBL_IMPORT' => 'Importar Libros',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Libro record by importing a vCard from your file system.',
  'LBL_E3_BOOKS_FOCUS_DRAWER_DASHBOARD' => 'Libros Panel de Enfoque',
  'LBL_E3_BOOKS_RECORD_DASHBOARD' => 'Libros Tablero de Registro',
  'LBL_TCT_ID_LIBRO_TXF' => 'ID Libro',
  'LBL_TCT_TITULO_TXF' => 'Título',
  'LBL_TCT_NUM_PAGS_TXF' => 'Número de páginas',
  'LBL_TCT_RESUMEN_TXA' => 'Área de texto',
  'LBL_TCT_PUBLICACION_DAT' => 'Fecha de publicación',
);